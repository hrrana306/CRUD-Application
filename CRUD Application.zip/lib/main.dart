import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      theme: ThemeData(
        primarySwatch: Colors.blueGrey,
      ),
      home: const MyHomePage(title: 'CRUD Functions'),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatefulWidget {
  final String title;

  const MyHomePage({Key? key, required this.title}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // Variables to hold the form input values
  String? name, email, city, phoneNumber;

  // Local list to store user data
  final List<Map<String, String?>> userList = [];

  // Create data method
  void createData() {
    if (name == null || name!.isEmpty) {
      print("Error: Name is required to create a document.");
      return;
    }

    Map<String, String?> user = {
      "Name": name,
      "Email": email,
      "City": city,
      "PhoneNumber": phoneNumber,
    };

    userList.add(user);
    print("$name created");
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("$name created")),
    );

    // Clear fields after creating
    clearFields();
  }

  // Read data method
  void readData() {
    if (name == null || name!.isEmpty) {
      print("Error: Name is required to read a document.");
      return;
    }

    final user = userList.firstWhere(
      (user) => user["Name"] == name,
      orElse: () => {},
    );

    if (user.isNotEmpty) {
      print("Data: $user");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Data: ${user.toString()}")),
      );
    } else {
      print("No document found with name $name");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("No document found with name $name")),
      );
    }
  }

  // Update data method
  void updateData() {
    if (name == null || name!.isEmpty) {
      print("Error: Name is required to update a document.");
      return;
    }

    final userIndex = userList.indexWhere((user) => user["Name"] == name);

    if (userIndex != -1) {
      userList[userIndex] = {
        "Name": name,
        "Email": email,
        "City": city,
        "PhoneNumber": phoneNumber,
      };

      print("$name updated");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Data updated for $name")),
      );
    } else {
      print("No document found with name $name");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("No document found with name $name")),
      );
    }
  }

  // Delete data method
  void deleteData() {
    if (name == null || name!.isEmpty) {
      print("Error: Name is required to delete a document.");
      return;
    }

    final userIndex = userList.indexWhere((user) => user["Name"] == name);

    if (userIndex != -1) {
      userList.removeAt(userIndex);
      print("$name deleted");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Data deleted for $name")),
      );
    } else {
      print("No document found with name $name");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("No document found with name $name")),
      );
    }
  }

  // Clear input fields
  void clearFields() {
    setState(() {
      name = null;
      email = null;
      city = null;
      phoneNumber = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        backgroundColor: Colors.blueGrey,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextFormField(
              decoration: const InputDecoration(
                labelText: "Name",
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue, width: 2),
                ),
              ),
              onChanged: (String name) {
                setState(() {
                  this.name = name;
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextFormField(
              decoration: const InputDecoration(
                labelText: "Email",
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue, width: 2),
                ),
              ),
              onChanged: (String email) {
                setState(() {
                  this.email = email;
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextFormField(
              decoration: const InputDecoration(
                labelText: "City",
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue, width: 2),
                ),
              ),
              onChanged: (String city) {
                setState(() {
                  this.city = city;
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: TextFormField(
              decoration: const InputDecoration(
                labelText: "Phone Number",
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blue, width: 2),
                ),
              ),
              onChanged: (String number) {
                setState(() {
                  this.phoneNumber = number;
                });
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text("Create"),
                  onPressed: createData,
                ),
                const SizedBox(width: 8), // Space between buttons
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text("Read"),
                  onPressed: readData,
                ),
                const SizedBox(width: 8), // Space between buttons
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: const Text("Update"),
                  onPressed: updateData,
                ),
                const SizedBox(width: 8), // Space between buttons
                ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueGrey,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: const Text("Delete"),
                  onPressed: deleteData,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
